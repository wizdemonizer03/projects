package com.Model;

public class Transaction {

}
